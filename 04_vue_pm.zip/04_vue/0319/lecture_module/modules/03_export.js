const name = "홍길동";
const age = 30;

function greet() {
  return `안녕하세요 ${name}입니다.`;
}

export { name, age, greet };
