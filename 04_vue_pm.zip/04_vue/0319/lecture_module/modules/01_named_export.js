/**
 * 이름이 있는 내보내기
 * -여러값을 내보낼수있다.
 * -반드시 기존이름을 사용하거나, as를 통해 별칭을 부여
 */

export const name = "홍길동";
export const age = 30;

export function greet() {
  return `안녕하세요 ${name}입니다.`;
}
